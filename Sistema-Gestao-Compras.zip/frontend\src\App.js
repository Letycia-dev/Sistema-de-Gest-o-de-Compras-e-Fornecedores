import { useEffect, useState } from "react";
import api from "./services/api";

function App() {
  const [fornecedores, setFornecedores] = useState([]);
  const [nome, setNome] = useState("");

  useEffect(() => {
    api.get("/fornecedores").then(response => {
      setFornecedores(response.data);
    });
  }, []);

  const cadastrarFornecedor = async () => {
    await api.post("/fornecedores", { nome });
    setFornecedores([...fornecedores, { nome }]);
    setNome("");
  };

  return (
    <div style={{ padding: 20 }}>
      <h1>Sistema de Gestão de Compras</h1>

      <h2>Cadastrar Fornecedor</h2>
      <input
        value={nome}
        onChange={e => setNome(e.target.value)}
        placeholder="Nome do fornecedor"
      />
      <button onClick={cadastrarFornecedor}>Cadastrar</button>

      <h2>Fornecedores</h2>
      <ul>
        {fornecedores.map((f, index) => (
          <li key={index}>{f.nome}</li>
        ))}
      </ul>
    </div>
  );
}

export default App;
