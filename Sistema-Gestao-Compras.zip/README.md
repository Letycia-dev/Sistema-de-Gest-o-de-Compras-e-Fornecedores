# Sistema de Gestão de Compras e Fornecedores

Aplicação Full Stack simples desenvolvida com **React** no front-end e **Python (Flask)** no back-end para gerenciar fornecedores.

## 🎯 Funcionalidades

### Front-end (React)
- ✅ Tela de login (simples, sem autenticação real)
- ✅ Cadastro, edição e exclusão (CRUD) de:
  - Fornecedores
  - Produtos
  - Pedidos de compra
- ✅ Listagem de dados em tabelas responsivas
- ✅ Formulários com validação de dados
- ✅ Consumo de API REST
- ✅ Interface responsiva e moderna

### Back-end (Python/Flask)
- ✅ API REST RESTful
- ✅ Endpoints para CRUD completo:
  - `/api/fornecedores` - Gerenciar fornecedores
  - `/api/produtos` - Gerenciar produtos
  - `/api/pedidos` - Gerenciar pedidos
- ✅ Validação de dados
- ✅ Integração com banco de dados
- ✅ Retorno de dados em JSON
- ✅ CORS habilitado

### Banco de Dados
- ✅ Banco relacional SQLite
- ✅ Relacionamento entre tabelas
- ✅ Persistência automática de dados

## 🛠️ Tecnologias Utilizadas

| Camada | Tecnologias |
|--------|-----------|
| **Frontend** | React, JavaScript, HTML5, CSS3 |
| **Backend** | Python, Flask, Flask-SQLAlchemy |
| **Banco de Dados** | SQLite |
| **API** | REST com JSON |
| **Versionamento** | Git, GitHub |

## 📂 Estrutura do Projeto

```
sistema-gestao-compras/
│
├── backend/
│   ├── app.py                 # Aplicação principal Flask
│   ├── requirements.txt       # Dependências Python
│   ├── database.db           # Banco de dados (gerado)
│   ├── models/
│   │   ├── __init__.py
│   │   └── models.py         # Modelos SQLAlchemy
│   └── routes/
│       ├── __init__.py
│       ├── fornecedores.py   # Endpoints fornecedores
│       ├── produtos.py       # Endpoints produtos
│       └── pedidos.py        # Endpoints pedidos
│
├── frontend/
│   ├── public/
│   │   └── index.html        # HTML principal
│   ├── src/
│   │   ├── App.js            # Componente raiz
│   │   ├── index.js          # Entrada React
│   │   ├── components/
│   │   │   ├── Navbar.js
│   │   │   ├── FormFornecedor.js
│   │   │   ├── TabelaFornecedores.js
│   │   │   ├── TabelaProdutos.js
│   │   │   └── TabelaPedidos.js
│   │   ├── pages/
│   │   │   ├── Login.js
│   │   │   ├── Dashboard.js
│   │   │   ├── Fornecedores.js
│   │   │   ├── Produtos.js
│   │   │   └── Pedidos.js
│   │   ├── services/
│   │   │   └── api.js        # Cliente API (Axios)
│   │   └── styles/
│   │       ├── index.css
│   │       ├── App.css
│   │       ├── Navbar.css
│   │       ├── Auth.css
│   │       ├── Dashboard.css
│   │       ├── Page.css
│   │       ├── Form.css
│   │       └── Table.css
│   └── package.json
│
├── .gitignore
└── README.md
```

## 🚀 Como Executar

### Pré-requisitos
- Python 3.8+
- Node.js 14+
- npm ou yarn

### Instalação e Execução - Backend

1. **Navegue para a pasta backend:**
   ```bash
   cd backend
   ```

2. **Crie um ambiente virtual:**
   ```bash
   python -m venv venv
   ```

3. **Ative o ambiente virtual:**
   - Windows:
     ```bash
     venv\Scripts\activate
     ```
   - macOS/Linux:
     ```bash
     source venv/bin/activate
     ```

4. **Instale as dependências:**
   ```bash
   pip install -r requirements.txt
   ```

5. **Execute a aplicação:**
   ```bash
   python app.py
   ```

   A API estará disponível em: `http://localhost:5000`

### Instalação e Execução - Frontend

1. **Abra outro terminal e navegue para a pasta frontend:**
   ```bash
   cd frontend
   ```

2. **Instale as dependências:**
   ```bash
   npm install
   ```

3. **Inicie o servidor de desenvolvimento:**
   ```bash
   npm start
   ```

   A aplicação abrirá em: `http://localhost:3000`

## 📝 Credenciais de Teste

- **Email:** `admin@empresa.com`
- **Senha:** `123456`

(Qualquer combinação de email/senha funcionará na demonstração)

## 🔗 Endpoints da API

### Fornecedores
- `GET /api/fornecedores` - Listar todos
- `GET /api/fornecedores/<id>` - Obter um
- `POST /api/fornecedores` - Criar novo
- `PUT /api/fornecedores/<id>` - Atualizar
- `DELETE /api/fornecedores/<id>` - Deletar

### Produtos
- `GET /api/produtos` - Listar todos
- `GET /api/produtos/<id>` - Obter um
- `POST /api/produtos` - Criar novo
- `PUT /api/produtos/<id>` - Atualizar
- `DELETE /api/produtos/<id>` - Deletar

### Pedidos
- `GET /api/pedidos` - Listar todos
- `GET /api/pedidos/<id>` - Obter um
- `POST /api/pedidos` - Criar novo
- `PUT /api/pedidos/<id>` - Atualizar
- `DELETE /api/pedidos/<id>` - Deletar

## ✨ Diferenciais do Projeto

- 🎨 Interface moderna e responsiva
- 🔒 Validação de dados em frontend e backend
- 📱 Design mobile-friendly
- 🔄 Sincronização automática de dados
- 📊 Tabelas intuitivas com ações rápidas
- 🎯 Código bem organizado e documentado
- 🌐 Integração Full Stack completa
- 💾 Persistência em banco de dados relacional

## 🎓 Por que esse projeto é perfeito para o currículo

✅ **Realista** - Empresas usam esse tipo de sistema de verdade  
✅ **Completo** - Demonstra conhecimento Full Stack  
✅ **Profissional** - Mostra boas práticas de desenvolvimento  
✅ **Comunicável** - Fácil de explicar em entrevistas  
✅ **Portfólio** - Não parece "projeto de curso genérico"  
✅ **Escalável** - Pode adicionar novas funcionalidades facilmente  

## 📚 Como Explicar em uma Entrevista

> "Desenvolvei um **Sistema de Gestão de Compras e Fornecedores** Full Stack, utilizando **React** no frontend para criar uma interface responsiva e intuitiva, e **Python com Flask** no backend para construir uma API REST robusta. O sistema implementa operações completas de CRUD para gerenciar fornecedores, produtos e pedidos de compra, com validação de dados em ambas as camadas e persistência em um banco de dados **SQLite**. A aplicação demonstra meu conhecimento em desenvolvimento web completo, desde a interface do usuário até a lógica de negócio e armazenamento de dados."

## 🤝 Contribuições

Este é um projeto modelo para fins educacionais e de portfólio. Sinta-se livre para:
- ✅ Fazer fork e melhorar
- ✅ Adicionar novas funcionalidades
- ✅ Melhorar a UI/UX
- ✅ Adicionar testes

## 📄 Licença

Este projeto é de código aberto e está disponível para uso educacional e profissional.

---

**Desenvolvido com ❤️ para demonstrar habilidades Full Stack**
