# 📤 Publicar no GitHub

## Passo 1: Criar Repositório no GitHub

1. Acesse https://github.com/new
2. Preencha os dados:
   - **Repository name**: `Sistema-Gestao-Compras` (ou outro nome)
   - **Description**: "Simplified Full Stack project with Flask backend and React frontend"
   - **Visibility**: Public (para portfólio)
3. Clique em **Create repository**
4. **NÃO** inicialize com README (já temos um)

## Passo 2: Instalar Git

Baixe Git em: https://git-scm.com/download/win

Durante instalação:
- Use **Git Bash** como terminal padrão
- Use **main** como nome padrão de branch

## Passo 3: Abrir Git Bash

1. Na pasta do projeto, clique com botão direito
2. Selecione **"Git Bash Here"**
3. Execute os comandos abaixo

## Passo 4: Comandos para Commitar

```bash
# Configurar Git (primeira vez apenas)
git config --global user.name "Letycia-Dev"
git config --global user.email "seu-email@github.com"

# Inicializar repositório local
git init

# Adicionar todos os arquivos
git add .

# Fazer commit
git commit -m "Initial commit: Simplified Full Stack project - Flask backend and React frontend"

# Adicionar remote do GitHub
git remote add origin https://github.com/Letycia-Dev/Sistema-Gestao-Compras.git

# Renomear branch para main
git branch -M main

# Fazer push (primeira vez)
git push -u origin main
```

## ✅ Pronto!

Seu projeto estará em: **https://github.com/Letycia-Dev/Sistema-Gestao-Compras**

## Commits Futuros

Para próximos commits:

```bash
git add .
git commit -m "Descrição da mudança"
git push
```

## 💡 Dicas

- Use mensagens de commit descritivas
- Faça commits frequentes (cada feature/fix)
- Use `git status` para ver arquivos modificados
- Use `git log` para ver histórico de commits
