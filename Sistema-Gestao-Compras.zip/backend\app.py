from flask import Flask, jsonify, request
from flask_cors import CORS
from models import fornecedores, produtos

app = Flask(__name__)
CORS(app)

# -------- FORNECEDORES --------
@app.route("/fornecedores", methods=["GET"])
def listar_fornecedores():
    return jsonify(fornecedores)

@app.route("/fornecedores", methods=["POST"])
def criar_fornecedor():
    data = request.json
    fornecedores.append(data)
    return jsonify({"mensagem": "Fornecedor cadastrado com sucesso"}), 201

# -------- PRODUTOS --------
@app.route("/produtos", methods=["GET"])
def listar_produtos():
    return jsonify(produtos)

@app.route("/produtos", methods=["POST"])
def criar_produto():
    data = request.json
    produtos.append(data)
    return jsonify({"mensagem": "Produto cadastrado com sucesso"}), 201

if __name__ == "__main__":
    app.run(debug=True)
