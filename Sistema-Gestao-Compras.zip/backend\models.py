fornecedores = []
produtos = []
